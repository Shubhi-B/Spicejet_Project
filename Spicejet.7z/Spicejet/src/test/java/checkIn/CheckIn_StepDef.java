package checkIn;

import org.openqa.selenium.support.ui.ExpectedConditions;

import hooks.Instances;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import repository.CheckIn_Repo;

public class CheckIn_StepDef extends Instances
{
	CheckIn_Repo checkin = new CheckIn_Repo();



	@Given("^User clicks on checkin$")
	public void user_clicks_on_checkin() throws InterruptedException 
	{
		Thread.sleep(3000);
//		jse.executeScript("arguments[0].click();", checkin.checkin(driver));
		a.moveToElement(checkin.checkin(driver)).click().perform();
	}

	@When("^\"(.*)\" is entered in PNR$")
	public void is_entered_in_pnr(String pnr) 
	{
		checkin.pnr(driver).sendKeys(pnr);
	}

	@When("^\"(.*)\" is entered in email field$")
	public void is_entered_in_email_field(String email) 
	{
		checkin.email(driver).sendKeys(email);
	}

	@When("^Search bookings button is clicked$")
	public void search_bookings_button_is_clicked() 
	{
		checkin.search(driver).click();
	}

	@Then("^user sees checkin results$")
	public void user_sees_search_results() throws InterruptedException 
	{
		Thread.sleep(3000);
		if (!driver.getCurrentUrl().contains("search")) 
		{
			System.out.println("-------No results found---------");
		} else
		{
			System.out.println("----Search Successful-----");
		}

	}
}
