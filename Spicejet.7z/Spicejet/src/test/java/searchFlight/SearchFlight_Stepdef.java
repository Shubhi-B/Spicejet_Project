package searchFlight;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import hooks.Instances;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import repository.SearchFlight_repo;

public class SearchFlight_Stepdef extends Instances 
{

	SearchFlight_repo search = new SearchFlight_repo();

	public  void loader()
	{
		try {
			if((search.loader(driver).isDisplayed()))
			{
				System.out.println("----Loading----");
				wait.until(ExpectedConditions.invisibilityOf(search.loader(driver)));
			}
		}
		catch(Exception e)
		{
			if((!search.loader(driver).isDisplayed()))
			{
				System.out.println(e.getMessage());
				System.out.println("---lOADED successfully---");
			}
		}
	}

	@Given("^User is on home page under Flights tab$")
	public void user_is_on_home_page() 
	{
		Assert.assertTrue(search.selectedTab(driver).getText().contains("Flights"));
	}

	@When("^\"(.*)\" is selected in radio button$")
	public void trip(String input)
	{
		for (WebElement element : search.trip(driver)) 
		{
			if (element.getText().equalsIgnoreCase(input))
			{
				element.click();
				break;
			} 
			else
				throw new Search_Exceptions("invalid input");
		}
	}

	@And("^\"(.*)\" is selected from From dropdown$")
	public void from_is_selected(String source) 
	{

		search.from(driver).click();

		for (WebElement element_list : search.fromList_outer(driver)) 
		{
			if (element_list.getText().contains(source))
			{
				System.out.println(element_list.getText());
				for (WebElement element_InList : search.fromList_inner(driver))

				{
					System.out.println("\n" + element_InList.getText());
					if (element_InList.getText().equalsIgnoreCase(source)) 
					{
						System.out.println("---source selected successfully--- "+source);
						element_InList.click();
						break;
					}
				}
			} else
			{
				search.fromInternational(driver).click();
				if (element_list.getText().contains(source)) 
				{
					System.out.println("inlist 2");
					for (WebElement element_InList : search.fromList_inner(driver))

					{
						System.out.println("\n" + element_InList.getText());
						if (element_InList.getText().equalsIgnoreCase(source)) 
						{
							System.out.println("---source selected successfully--- " + source);
							element_InList.click();
							break;
						}
					}
				}
			}
		}
	}

	String dest;

	@And("^\"(.*)\" is selected from To dropdown$")
	public void to_is_selected(String destination) throws InterruptedException
	{
		dest = destination;
		Thread.sleep(4000);
		for (WebElement element_list : search.toList_outer(driver))
		{
			System.out.println(element_list.getText());
			System.out.println(destination);
			if (element_list.getText().contains(destination))
			{
				for (WebElement element_InList : search.toList_inner(driver))

				{
					System.out.println("\n" + element_InList.getText());
					if (element_InList.getText().equalsIgnoreCase(destination))
					{
						System.out.println("---dest selected successfully--- "+destination);
						element_InList.click();
						break;
					}
				}
			} 
			else {
				search.toInternational(driver).click();
				if (element_list.getText().contains(destination)) 
				{
					for (WebElement element_InList : search.toList_inner(driver))

					{
						System.out.println("\n" + element_InList.getText());
						if (element_InList.getText().contains(destination))
						{
							System.out.println("---dest selected successfully--- "+destination);
							element_InList.click();
							break;
						}
					}
				}
			}
		}
	}

	@And("^\"(.*)\",\"(.*)\",\"(.*)\" is selected from departure date$")
	public void dd_is_selected(String input_yr, String input_mon, String input_date) throws InterruptedException
	{
		int count = 0;

		Thread.sleep(5000);
		outerloop: {
			for (WebElement element : search.dep_YrMonthText(driver)) // yearmonth text list
			{
				count++;
				if ((element.getText().contains(input_yr)) && (element.getText().contains(input_mon)))

				{
					System.out.println(element.getText());
					System.out.println(count);
					for (WebElement element1 : search.dep_YrMonth(driver, count))
					{
						if (element1.getText().equals(input_date))
						{
							element1.click();
							break outerloop;
						}
					}
				} 
				else
					continue;
			}
		}

	}

	@And("^\"(.*)\",\"(.*)\",\"(.*)\" is selected from return date$")
	public void rd_is_selected(String input_yr, String input_mon, String input_date) throws InterruptedException 
	{
		int count = 0;
		System.out.println("\n" + count);
		Thread.sleep(3000);
		if (!(input_yr.isBlank() && input_mon.isBlank() && input_date.isBlank())) 
		{
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(
					"//div[@style='background-color: rgb(238, 238, 238); border-bottom-left-radius: 0px; border-top-left-radius: 0px;']")));
			if (search.rdEnable(driver).isDisplayed()) 
			{
				Thread.sleep(2000);
				search.rdEnable(driver).click();
				outerloop1: {
					for (WebElement element : search.dep_YrMonthText(driver)) // yearmonth text list
					{
						System.out.println(search.dep_YrMonthText(driver).size());
						System.out.println(count);
						System.out.println(element.getText());
						count++;
						if ((element.getText().contains(input_yr)) && (element.getText().contains(input_mon))) 
						{
							System.out.println(element.getText());
							System.out.println(count);
							for (WebElement element1 : search.dep_YrMonth(driver, count))
							{
								if (element1.getText().equals(input_date)) 
								{
									element1.click();
									break outerloop1;
								}
							}
						} 
						else
							continue;
					}
				}

			} 
			else
			{
				outerloop: {
					for (WebElement element : search.dep_YrMonthText(driver)) // yearmonth text list
					{
						count++;
						if ((element.getText().contains(input_yr)) && (element.getText().contains(input_mon)))

						{
							System.out.println(count);
							for (WebElement element1 : search.dep_YrMonth(driver, count))
							{
								if (element1.getText().equals(input_date)) 
								{
									element1.click();
									break outerloop;
								}
							}
						} else
							continue;
					}
				}
			}
		}
	}

	@And("^Adult \"(.*)\",Children \"(.*)\",Infant \"(.*)\" is selected from passengers dropdown$")
	public void passengers_is_selected(String adult, String children, String infant) throws InterruptedException
	{
		Thread.sleep(3000);
		search.passengers(driver).click();
		String[] pass = { adult, children, infant };
		System.out.println((Integer.parseInt(children) + Integer.parseInt(adult)));
		System.out.println(Integer.parseInt(infant));
		if ((Integer.parseInt(children) + Integer.parseInt(adult) <= 9)
				&& (Integer.parseInt(infant) <= Integer.parseInt(adult)))
		{

			for (int i = 0; i < pass.length; i++)
			{
				String passtext = search.passengersCount(driver, i + 1).getText();

				if (!passtext.equals(pass[i])) 
				{

					for (int j = 1; j < 9; j++)
					{
						Thread.sleep(2000);

						search.passengersIncreaseCount(driver, i + 1).click();
						Thread.sleep(2000);
						if (search.passengersCount(driver, i + 1).getText().equals(pass[i]))
						{
							break;
						}
					}
				}

			}

		}
		else
		{
			System.out.println("stop");
		}

		search.doneButton(driver).click();

	}

	@And("^\"(.*)\" is selected from currency dropdown$")
	public void currency_is_selected(String currency) throws InterruptedException 
	{
		Thread.sleep(3000);
		search.currency(driver).click();
		for (WebElement element : search.currencyList(driver))
		{
			if (element.getText().equals(currency)) 
			{
				element.click();
				break;
			}
			else
				continue;

		}

	}

	@And("^Any discount discountname - \"(.*)\" if applicable is selected$")
	public void any_discount_if_applicable_is_selected(String discount) 
	{
		if (!discount.isBlank()) {
			for (WebElement element : search.discounts(driver))
			{
				System.out.println(element.getText());
				if (element.getText().equalsIgnoreCase(discount))
				{
					element.click();
					break;
				} 
				else
					continue;
			}
		}
	}

	@And("^search flight button is clicked$")
	public void click() throws InterruptedException
	{

		Thread.sleep(2000);
		search.button(driver).click();
		wait.until(ExpectedConditions.urlContains("redirectTo"));
		loader();
		Thread.sleep(7000); //due to discount modal popping briefly

		i: {
			if (search.iAgree(driver) != null && search.iAgree(driver).isDisplayed()) 
			{
				search.iAgree(driver).click();
				Thread.sleep(2000);
				break i;
			}
		}

		j: {
			if (search.terms(driver) != null && search.terms(driver).isDisplayed())
			{
				search.termsAccept(driver).click();
				Thread.sleep(2000);

				search.termsContinue(driver).click();
				break j;
			}
		}

	}

	@And("^User should be able to see search results$")
	public void search_results()
	{
		int c1 = 1;
		try
		{
			wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//div[@class='css-1dbjc4n r-1xdf14d']")));
			int resultfoundSize = search.resultsFound(driver).size();
			System.out.println("Results in list size " + resultfoundSize);

			if (resultfoundSize == 1)
			{
				for (int i = 1; i <= search.ListflightDetails(driver, c1).size(); i++) 
				{
					System.out.println(c1 + " " + i);
					wait.until(ExpectedConditions.elementToBeClickable((search.flightDetails(driver, c1, i))));
					a.moveToElement((search.flightDetails(driver, c1, i))).click().perform();
					Thread.sleep(2000);

				}
			} 
			else if (resultfoundSize == 2) 
			{
				int i = 0;
				while (i < 2)
				{
					for (int j = 1; j <= search.ListflightDetails(driver, c1).size(); j++) 
					{
						System.out.println(c1 + " " + j);
						wait.until(ExpectedConditions.elementToBeClickable((search.flightDetails(driver, c1, j))));

						a.moveToElement((search.flightDetails(driver, c1, j))).click().perform();
						Thread.sleep(4000);
					}
					i++;
					c1++;
				}

			} 
		}
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
			System.out.println("---------No Flights Available----------");
		}

	}

	@Then("^User selects price and clicks on continue$")
	public void user_selects_price_and_clicks_on_continue() throws InterruptedException
	{
		Thread.sleep(10000); // to select price
		try {
			if ((search.continueButton(driver)!=null) && (search.continueButton(driver).getText().contains("Continue")) )
			{
				wait.until(ExpectedConditions.elementToBeClickable(search.continueButton(driver)));
				search.continueButton(driver).click();
				System.out.println("---Redirected to booking ---");

			} 
			else
				throw new Search_Exceptions("no results");
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
			System.out.println("--------Search Again-----------");
		}
	}

}
