package searchFlight;

public class Search_Exceptions extends RuntimeException
{
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	public Search_Exceptions(String s) {
	
		super(s);// TODO Auto-generated constructor stub
	}

	
}
