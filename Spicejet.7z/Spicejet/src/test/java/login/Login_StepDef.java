package login;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

import hooks.Instances;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import repository.Login_repo;

public class Login_StepDef extends Instances
{
	Login_repo login= new Login_repo();
	String error;

	public void loader()
	{
		try
		{
			if((login.loader(driver).isDisplayed()))
			{
				System.out.println("---Loading--");
				wait.until(ExpectedConditions.invisibilityOf(login.loader(driver)));
			}
		}
		catch(Exception e)
		{
			System.out.println("---loaded successfully---");
		}
	}

	@Given("^User is on login page$")
	public void user_is_on_login_page() 
	{
		login.login_link(driver).click();

	}

	@When("^(.*) is selected as either email or mobile number$")
	public void method_of_login_is_selected_as_either_email_or_mobilenumber(String methodOfLogin)
	{

		wait.until(ExpectedConditions.visibilityOf(login.login_text(driver)));
		if(methodOfLogin.equalsIgnoreCase("Email"))
		{

			login.radiobtn_emailTxt(driver).click();

		}
		else if (methodOfLogin.equalsIgnoreCase("Mobile Number"))
		{
			login.radiobtn_mobileTxt(driver).click();
		}

	}


	@When("^(.*) is entered in the respective field$")
	public void email_mobile_is_entered_in_the_respective_field(String input) throws InterruptedException {

		if(login.selected_Radiobutton(driver).getText().equals("Mobile Number"))
		{

			login.mobile(driver).sendKeys(input);
		}

		else if (login.selected_Radiobutton(driver).getText().equals("Email"))
		{

			login.email(driver).sendKeys(input);
		}


	}

	@When("^(.*) is entered in the Password field$")
	public void password_is_entered_in_the_password_field(String password) 
	{
		login.password(driver).sendKeys(password);
	}

	@When("^login button is clicked$")
	public void login_button_is_clicked() 
	{
		login.loginButton(driver).click();
	}

	@Then("^User should be able to login if the credentials are valid$")
	public void user_should_be_able_to_login_if_the_credentials_are_valid() throws InterruptedException 
	{
		loader();
		try
		{
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='css-1dbjc4n r-1jkjb']//div[@class='css-76zvg2 r-jwli3a r-ubezar r-1ozqkpa']")));
			if((login.loginSuccessful(driver).isDisplayed()))
			{
				login.loginSuccessful(driver).click();
				System.out.println("------login successful------");
			}


		}
		catch(Exception e)
		{
			System.out.println(e);
			System.out.println("------invalid credentials------");
		}

	}
}
