package hooks;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Instances 
{
	protected static WebDriver driver ;
	protected static WebDriverWait wait;
	protected static JavascriptExecutor jse;
	protected static Actions a;

	
}
