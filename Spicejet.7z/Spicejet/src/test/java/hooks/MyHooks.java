package hooks;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.github.bonigarcia.wdm.WebDriverManager;


//a class with step definitions or hooks cannot be extended so create another class with objects and extend
//in the glue add this class else null pointer exception
public class MyHooks extends Instances
{
	

	@Before
	public void beforeScenario( )
	{
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.spicejet.com/");

		wait=new WebDriverWait(driver,Duration.ofSeconds(60));
		jse=(JavascriptExecutor) driver;
		a=new Actions(driver);
	}
	
	@After
	public void afterScen() throws InterruptedException
	{
		Thread.sleep(10000);
		driver.quit();
	}
}
