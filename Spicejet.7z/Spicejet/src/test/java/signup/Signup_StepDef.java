package signup;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import hooks.Instances;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import repository.Signup_repo;
import searchFlight.Search_Exceptions;

public class Signup_StepDef extends Instances {

	Signup_repo signup = new Signup_repo();
	Select select;

	public void loader()
	{
		try
		{
			if((signup.loader1(driver).isDisplayed()))
			{
				System.out.println("---Loading--");
				wait.until(ExpectedConditions.invisibilityOf(signup.loader1(driver)));
			}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			System.out.println("---loaded successfully---");
		}
	}
	@Given("^User is on signup page$")
	public void user_is_on_signup_page() 
	{
		signup.signup(driver).click();
		String parentWindow = driver.getWindowHandle();
		for (String windowHandle : driver.getWindowHandles()) 
		{
			if(!parentWindow.contentEquals(windowHandle))
			{
				driver.switchTo().window(windowHandle);
				break;
			}
		}
	}

	@When("^(.*) is selected in title$")
	public void title_is_selected(String Title)
	{
		select = new Select(signup.get_title(driver)); // need to initialize here as select expects a Webelement so need
		select.selectByVisibleText(Title);
	}

	@And("^(.*) is entered in first name field$")
	public void first_name_and_middle_name_is_entered(String fn)
	{
		signup.get_firstname(driver).sendKeys(fn);
	}

	@And("^(.*) is entered in last name field$")
	public void last_name_is_entered(String ln)
	{
		signup.lastname(driver).sendKeys(ln);
	}

	@And("^(.*) is selected from country dropdown$")
	public void country_is_selected(String country)
	{
		select = new Select(signup.country(driver));
		select.selectByVisibleText(country);
	}

	@And("^(.*) and (.*) and (.*) is selected from calendar$")
	public void date_of_birth_is_selected(String year, String month, String input_date) throws InterruptedException
	{
		signup.calendar_icon(driver).click();
		select = new Select(signup.calendar_yr(driver));
		select.selectByValue(year);
		Thread.sleep(3000);
		select = new Select(signup.calendar_month(driver));
		select.selectByVisibleText(month);
		Thread.sleep(3000);
		signup.calendar_date(driver);
		for (WebElement calendar_date : signup.calendar_date(driver))
		{
			if (calendar_date.getText().equals(input_date)) 
			{
				calendar_date.click();
				break;
			}
		}
	}

	@And("^(.*) is entered in mobile number field$")
	public void mobile_number_is_entered(String number) throws InterruptedException 
	{
		signup.mobilenumber(driver).clear();
		signup.mobilenumber(driver).sendKeys(number);
		Thread.sleep(2000);

		signup.mobilenumber(driver).sendKeys(Keys.ENTER);
		loader();
	}

	@And("^(.*) is entered in email id field$")
	public void email_id_is_entered(String email) throws InterruptedException 
	{
		signup.email(driver).sendKeys(email);
		signup.email(driver).sendKeys(Keys.TAB);
		loader();

	}

	@And("^and (.*) is entered in password field$")
	public void password_is_entered(String password) throws InterruptedException 
	{
		signup.get_password(driver).sendKeys(password);
		signup.get_password(driver).sendKeys(Keys.TAB);
		
	}

	@And("^(.*) is entered in confirm password field$")
	public void confirm_password_is_entered(String c_pwd) throws InterruptedException
	{
		signup.confirm_password(driver).sendKeys(c_pwd);
		loader();
	}
	
	@And("^Terms and conditions are accepted$")
	public void terms_and_conditions_are_accepted() throws InterruptedException
	{
		wait.until(ExpectedConditions.elementToBeClickable(signup.accept_terms(driver)));
		jse.executeScript("arguments[0].click();", signup.accept_terms(driver));
	}

	@And("^Submit button is clicked$")
	public void submit_button_is_clicked() throws InterruptedException 
	{
		
		if((signup.submit(driver).isEnabled()))
		{
			System.out.println("yes");
			jse.executeScript("arguments[0].click();", signup.submit(driver));
			//signup.submit(driver).click();
		}
		else
			throw new Search_Exceptions("---Registration Unsuccessful---");
	}

	@And("^User enters OTP$")
	public void user_is_successfully_registered() throws InterruptedException
	{
		Thread.sleep(15000);  //enter otp manually
		signup.verify(driver).click();
	}
	
	@Then("^user lands on dashboard$")
	public void user_lands_on_dashboard() throws InterruptedException
	{
		try {
			wait.until(ExpectedConditions.urlContains("dashboard"));
			System.out.println("--------Successfully registered-----------");
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
			System.out.println("------Invalid otp--Registration Unsuccessful-----");
		}
	}
}


