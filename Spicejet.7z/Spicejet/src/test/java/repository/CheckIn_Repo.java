package repository;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CheckIn_Repo
{
	WebElement element;
	 List<WebElement> elements;
	
	public WebElement checkin(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//body/div[@id='react-root']/div[@id='main-container']/div[@data-testid='application-id']/div/div[3]/div[1]/div[2]"));
		return element;
	}
	public WebElement pnr(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//input[@placeholder='e.g. W3X3H8']"));
		return element;
	}
	
	public WebElement email(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//input[@placeholder='john.doe@spicejet.com']"));
		return element;
	}
	public WebElement search(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//div[@class='css-1dbjc4n r-1awozwy r-19m6qjp r-z2wwpe r-1loqt21 r-18u37iz r-1777fci r-1w50u8q r-ah5dr5 r-1otgn73 r-13qz1uu']"));
		return element;
	}
//	public WebElement button(WebDriver driver)
//	{
//		element=driver.findElement(By.xpath(""));
//		return element;
//	}
}


