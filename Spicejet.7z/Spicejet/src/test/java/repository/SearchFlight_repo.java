package repository;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SearchFlight_repo {
	static WebElement element;
	static List<WebElement> elements;

	public WebElement selectedTab(WebDriver driver) {
		element = driver.findElement(By.xpath("//div[@class='css-76zvg2 r-jwli3a r-ubezar r-1ozqkpa']"));
		return element;
	}
	
	public WebElement loader(WebDriver driver) {
		element = driver.findElement(By.xpath("//div[@class='css-1dbjc4n r-1awozwy r-l0gwng']"));
		return element;
	}
	//Trip type
	public List<WebElement> trip(WebDriver driver) {
		elements = driver.findElements(By.xpath(
				"(//div[@class='css-1dbjc4n r-18u37iz r-1w6e6rj'])[1]//div[@class='css-76zvg2 r-homxoj r-ubezar r-1ozqkpa']"));
		return elements;
	}

	//FROM SOURCE
	public WebElement from(WebDriver driver) {
		element = driver.findElement(By.xpath("(//div[@data-testid='to-testID-origin'])[1]"));
		return element;
	}

	public List<WebElement> fromList_outer(WebDriver driver) {
		elements = driver
				.findElements(By.xpath("//div[@data-testid='to-testID-origin']//div[@class='css-1dbjc4n r-19yat4t r-1rt2jqs']/div[2]"));

		return elements;
	}

	public List<WebElement> fromList_inner(WebDriver driver) {
		List<WebElement> elements1 = driver
				.findElements(By.xpath("//div[@class='css-1dbjc4n r-19yat4t r-1rt2jqs']/div[2]/div/div[1]/div[1]/div"));

		return elements1;
	}

	public WebElement fromInternational(WebDriver driver) {
		element = driver.findElement(By.xpath("//div[text()='International']"));
		return element;
	}
	//TO DESTINATION
	public WebElement toText(WebDriver driver) {
		element = driver.findElement(By.xpath("(//div[text()='Select a region and city below' and @class='css-76zvg2 r-qsz3a2 r-18tvxmy r-adyw6z r-1kfrs79'])"));
		return element;
	}

	public WebElement to(WebDriver driver) {
		element = driver.findElement(By.xpath("(//div[@data-testid='to-testID-destination'])[1]"));
		return element;
	}

	public List<WebElement> toList_outer(WebDriver driver) {
		elements = driver
				.findElements(By.xpath("//div[@data-testid='to-testID-destination']//div[@class='css-1dbjc4n r-19yat4t r-1rt2jqs']/div[2]"));

		return elements;
	}

	public List<WebElement> toList_inner(WebDriver driver) {
		List<WebElement> elements1 = driver
				.findElements(By.xpath("//div[@class='css-1dbjc4n r-19yat4t r-1rt2jqs']/div[2]/div/div[1]/div[1]/div"));

		return elements1;
	}

	public WebElement toInternational(WebDriver driver) {
		element = driver.findElement(By.xpath("//div[text()='International']"));
		return element;
	}

	public WebElement rdEnable(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//div[@style='background-color: rgb(238, 238, 238); border-bottom-left-radius: 0px; border-top-left-radius: 0px;']"));
		return element;
	}




	//DEPARTURE DATE
	public WebElement calendar(WebDriver driver) {
		element = driver.findElement(By.xpath("//div[@class='css-1dbjc4n r-14lw9ot r-11u4nky r-rs99b7 r-6koalj r-eqz5dr r-1pi2tsx r-pm9dpa r-1knelpx r-13qz1uu']"));
		return element;
	}

	public List<WebElement> dep_YrMonthText(WebDriver driver) {
		elements = driver
				.findElements(By.xpath("//div[@class='css-76zvg2 r-homxoj r-adyw6z r-1kfrs79']"));
		return elements;
	}
	public List<WebElement> return_YrMonthText(WebDriver driver) {
		elements = driver
				.findElements(By.xpath("//body/div[@id='react-root']/div[@id='main-container']/div[@class='css-1dbjc4n r-1niwhzg r-1jgb5lz r-r0h9e2 r-13qz1uu']/div[@class='css-1dbjc4n r-14lw9ot']/div[@class='css-1dbjc4n r-14lw9ot r-z2wwpe r-vgw6uq r-156q2ks r-urutk0 r-8uuktl r-136ojw6']/div[@class='css-1dbjc4n r-1pcd2l5 r-1uwte3a r-m611by r-bnwqim']/div[@class='css-1dbjc4n r-19h5ruw r-136ojw6']/div/div[@class='css-1dbjc4n r-1niwhzg r-z2wwpe r-17b9qp5 r-1g94qm0 r-h3f8nf r-u8s1d r-u3yave r-8fdsdq']/div[@class='css-1dbjc4n r-14lw9ot r-11u4nky r-rs99b7 r-6koalj r-eqz5dr r-1pi2tsx r-pm9dpa r-1knelpx r-13qz1uu']/div[@class='css-1dbjc4n r-1euycsn']/div[@class='css-1dbjc4n r-150rngu r-18u37iz r-16y2uox r-1wbh5a2 r-lltvgl r-buy8e9 r-1sncvnh']/div[@class='css-1dbjc4n r-18u37iz']/div/div[1]/div[1]/div"));
		return elements;
	}
	
	public List<WebElement> return_YrMonth(WebDriver driver, int count) {

		elements = driver.findElements(By.xpath(
				"//div[@class='css-1dbjc4n r-150rngu r-18u37iz r-16y2uox r-1wbh5a2 r-lltvgl r-buy8e9 r-1sncvnh']/div/div["+count+"]//div[@class='css-76zvg2 r-homxoj r-ubezar r-16dba41' or @class='css-76zvg2 r-jwli3a r-ubezar r-16dba41']"));

		return elements;
	}

	public List<WebElement> dep_YrMonth(WebDriver driver, int count) {

		elements = driver.findElements(By.xpath(
				"//div[@class='css-1dbjc4n r-150rngu r-18u37iz r-16y2uox r-1wbh5a2 r-lltvgl r-buy8e9 r-1sncvnh']/div/div["+count+"]//div[@class='css-76zvg2 r-homxoj r-ubezar r-16dba41' or @class='css-76zvg2 r-jwli3a r-ubezar r-16dba41']"));

		return elements;
	}

	//PASSENGERS
	public WebElement passengers(WebDriver driver) {
		element = driver.findElement(By.xpath("//div[@data-testid='home-page-travellers']"));
		return element;
	}


	public List<WebElement> passengersList(WebDriver driver) {

		elements = driver.findElements(By.xpath
				("//div[@class='css-1dbjc4n r-18u37iz r-1wtj0ep r-1x0uki6']"));

		return elements;
	}

	public WebElement passengersCount(WebDriver driver, int c) {

		element = driver.findElement(By.xpath
				("/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/div[3]/div[2]/div[5]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div["+c+"]/div[2]/div[2]/div[1]"));

		return element;
	}

	public WebElement passengersIncreaseCount(WebDriver driver, int d)  {
		element=driver.findElement(By.xpath("/html/body/div[2]/div/div/div[1]/div[3]/div[2]/div[5]/div[1]/div/div[2]/div[2]/div/div[1]/div["+d+"]/div[2]/div[3]"));

		return element;
	}

	public WebElement doneButton(WebDriver driver)  
	{
		element=driver.findElement(By.xpath("//div[@class='css-1dbjc4n r-1awozwy r-19m6qjp r-z2wwpe r-1loqt21 r-18u37iz r-1777fci r-d9fdf6 r-1w50u8q r-ah5dr5 r-1otgn73']"));

		return element;
	}

	//DISCOUNTS
	public List<WebElement> discounts(WebDriver driver) {

		elements = driver.findElements(By.xpath(
				"//div[@class='css-1dbjc4n r-1d09ksm r-1inuy60 r-m611by']//div[@class='css-1dbjc4n r-1awozwy r-1loqt21 r-18u37iz r-15d164r r-1otgn73']//div[@class='css-76zvg2 r-cqee49 r-n6v787 r-1ozqkpa']"));

		return elements;
	}
	//CURRENCY
	public WebElement currency(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//div[ text()='Currency']"));
		return element;
	}

	public List<WebElement> currencyList(WebDriver driver) 
	{
		elements = driver.findElements
				(By.xpath("//div[@class='css-1dbjc4n r-1habvwh r-19fu0aa r-1loqt21 r-1777fci r-1mi0q7o r-1yt7n81 r-m611by r-1otgn73' or @class='css-1dbjc4n r-1habvwh r-1loqt21 r-1777fci r-1mi0q7o r-1yt7n81 r-m611by r-1otgn73']"));
		return elements;
	}


	//SEARCH BUTTON
	public WebElement button(WebDriver driver) {
		element = driver.findElement(By.xpath("//div[@data-testid='home-page-flight-cta']"));
		return element;
	}
	
	
	//SEARCH ERRORS AND ALERTS
	public WebElement error(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//div[@class='css-1dbjc4n r-715s5d r-182v25a r-1xfd6ze r-1phboty r-d045u9 r-kb7riz r-1oqcu8e']"));
		return element;
	}

	public WebElement terms(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//span[@class='css-76zvg2 css-16my406 r-1xedbs3']"));
		return element;
	}
	public WebElement termsContinue(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//div[@class='css-1dbjc4n r-1awozwy r-z2wwpe r-1loqt21 r-18u37iz r-1777fci r-d9fdf6 r-1w50u8q r-ah5dr5 r-1otgn73']"));
		return element;
	}
	public WebElement termsAccept(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[name()='rect' and contains(@width,'100%')]"));
		return element;
	}

	public WebElement searchAgain(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//div[@class='css-1dbjc4n r-1awozwy r-19m6qjp r-z2wwpe r-1loqt21 r-18u37iz r-1777fci r-9qu9m4 r-ah5dr5 r-1otgn73']"));
		return element;
	}

	public WebElement iAgree(WebDriver driver) {
		element=driver.findElement(By.xpath("//div[@class='css-76zvg2 r-19m6qjp r-z2wwpe r-jwli3a r-1b43r93 r-majxgm r-1guathk r-1w50u8q']"));
		return element;
	}
	//RESULLTS
	public List<WebElement> noResults(WebDriver driver) 
	{
		elements = driver.findElements
				(By.xpath("//div[@class='css-76zvg2 r-homxoj r-1x35g6 r-1kfrs79 r-15d164r r-38x2cy']"));
		return elements;
	}
	public WebElement noResult(WebDriver driver,int count) 
	{
		element = driver.findElement
				(By.xpath("(//div[@class='css-76zvg2 r-homxoj r-1x35g6 r-1kfrs79 r-15d164r r-38x2cy'])["+count+"]"));
		return element;
	}
	
	public WebElement resultFound(WebDriver driver,int count) 
	{
		element = driver.findElement
				(By.xpath("(//div[@class='css-1dbjc4n r-1xdf14d'])["+count+"]"));
		return element;
	}
	public List<WebElement> resultsFound(WebDriver driver) 
	{
		elements = driver.findElements
				(By.xpath("//div[@class='css-1dbjc4n r-1xdf14d']"));
		return elements;
	}
	public List<WebElement> ListflightDetails(WebDriver driver,int count) 
	{
		elements = driver.findElements
				(By.xpath("(//div[@class='css-1dbjc4n r-1xdf14d'])["+count+"]//div[@class='css-76zvg2 r-1xedbs3 r-n6v787 r-16dba41 r-7o8qx1 r-156q2ks']"));
		return elements;
	}
	public List<WebElement> OListflightDetails(WebDriver driver,int count) 
	{
		elements = driver.findElements
				(By.xpath("(//div[@class='css-1dbjc4n r-1xdf14d'])["+count+"]//div[@class='css-76zvg2 r-1xedbs3 r-n6v787 r-16dba41 r-7o8qx1 r-156q2ks']"));
		return elements;
	}
	public WebElement flightDetails(WebDriver driver,int c1,int c2) 
	{
		element = driver.findElement
				(By.xpath("((//div[@class='css-1dbjc4n r-1xdf14d'])["+c1+"]//div[@class='css-76zvg2 r-1xedbs3 r-n6v787 r-16dba41 r-7o8qx1 r-156q2ks'])["+c2+"]"));
		return element;
	}
	public WebElement continueButton(WebDriver driver) 
	{
		element = driver.findElement(By.xpath("//div[@class='css-1dbjc4n r-1awozwy r-1xfd6ze r-1loqt21 r-18u37iz r-1777fci r-1w50u8q r-ah5dr5 r-1otgn73']"));
		return element;
	}
}
