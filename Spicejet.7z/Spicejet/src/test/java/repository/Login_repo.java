package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Login_repo 
{
	
		static WebElement element;

		public WebElement login_text(WebDriver driver )
		{
			element = driver.findElement(By.xpath("//div[@class='css-76zvg2 r-homxoj r-18tvxmy r-adyw6z r-1kfrs79']"));
			return element;	
		}
		
		public WebElement login_link(WebDriver driver )
		{
			element = driver.findElement(By.xpath("//div[text()='Login']"));
			return element;	
		}
		
		public WebElement selected_Radiobutton(WebDriver driver )
		{
			element = driver.findElement(By.xpath("//div[@class='css-1dbjc4n r-18u37iz r-1w6e6rj r-p1pxzi']//*[name()='g']/../..//following-sibling::div"));
			return element;	
		}
		
		public WebElement radiobtn_mobileTxt(WebDriver driver )
		{
			element = driver.findElement(By.xpath("//div[text()='Mobile Number']"));
			return element;	
		}
		
		public WebElement password(WebDriver driver )
		{
			element = driver.findElement(By.xpath("//input[@type='password']"));
			return element;	
		}
		
		public WebElement mobile(WebDriver driver )
		{
			element = driver.findElement(By.xpath("//input[@type='number']"));
			return element;	
		}
		
		public WebElement radiobtn_emailTxt(WebDriver driver )
		{
			element = driver.findElement(By.xpath("//div[text()='Email']"));
			return element;	
		}
		
		public WebElement email(WebDriver driver )
		{
			element = driver.findElement(By.xpath("//input[@type='email']"));
			return element;	
		}
		
		public WebElement country_code(WebDriver driver )
		{
			element = driver.findElement(By.xpath("(//div[@class='css-1dbjc4n r-1awozwy r-1loqt21 r-6koalj r-18u37iz r-1otgn73 r-eafdt9 r-1i6wzkk r-lrvibr'])[1]"));
			return element;	
		}
		
		public WebElement forgot_pwd(WebDriver driver )
		{
			element = driver.findElement(By.xpath("//div[text()='Forgot Password?']"));
			return element;	
		}
			
		public WebElement loginButton(WebDriver driver )
		{
			element = driver.findElement(By.xpath("//div[@class='css-1dbjc4n r-1awozwy r-184aecr r-z2wwpe r-1loqt21 r-18u37iz r-tmtnm0 r-1777fci r-1x0uki6 r-1w50u8q r-ah5dr5 r-1otgn73']"));
			return element;	
		}
		public WebElement error(WebDriver driver )
		{
			element = driver.findElement(By.xpath("//div[@class='css-1dbjc4n r-1awozwy r-13awgt0 r-18u37iz']/div[2]"));
			return element;	
		}
		
		public WebElement loginSuccessful(WebDriver driver )
		{
			element = driver.findElement(By.xpath("//div[@class='css-1dbjc4n r-1jkjb']//div[@class='css-76zvg2 r-jwli3a r-ubezar r-1ozqkpa']"));
			return element;	
		}
		
		public WebElement logout(WebDriver driver )
		{
			element = driver.findElement(By.xpath("//div[@class='css-1dbjc4n r-1awozwy r-1loqt21 r-18u37iz r-1wtj0ep r-1j3t67a r-1w50u8q r-1otgn73']"));
			return element;	
		}
		public WebElement loader(WebDriver driver )
		{
			element = driver.findElement(By.xpath("//div[@class='css-1dbjc4n r-14lw9ot r-1mlwlqe r-1udh08x r-1lgpqti']"));
			return element;	
		}
	}

