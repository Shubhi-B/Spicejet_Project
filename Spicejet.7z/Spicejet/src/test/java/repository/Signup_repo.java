package repository;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Signup_repo
{
	static WebElement element;;
	
	public WebElement signup(WebDriver driver )
	{
		element = driver.findElement(By.xpath("//div[text()='Signup']"));
		return element;	
	}
	
	public WebElement get_title(WebDriver driver )
	{
		element = driver.findElement(By.xpath("//label[text()='Title']/..//select"));
		return element;	
	}

	public WebElement loader(WebDriver driver )
	{
		element = driver.findElement(By.cssSelector("img[src='https://spiceclub.spicejet.com/public/loader.gif']"));
		return element;	
	}

	public WebElement loader1(WebDriver driver )
	{
		element = driver.findElement(By.xpath("//div[@class='modal-body']"));
		return element;	
	}

	public WebElement get_firstname(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='first_name']"));
		return element;	
	}

	public WebElement lastname(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='last_name']"));
		return element;	
	}

	public WebElement country(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//label[text()='Country/Territory of Residence']/..//select"));
		return element;	
	}

	public WebElement mobilenumber(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//label[text()='Mobile Number']/..//input"));
		return element;	

	}

	public WebElement calendar_icon(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='dobDate']"));
		return element;
	}

	public WebElement calendar_yr(WebDriver driver)
	{

		WebElement year = driver.findElement(By.className("react-datepicker__year-select"));
		return year;
	}

	public WebElement calendar_month(WebDriver driver)
	{
		WebElement month = driver.findElement(By.className("react-datepicker__month-select"));
		return month;

	}
	public List<WebElement> calendar_date(WebDriver driver)
	{
		List<WebElement> elements = driver.findElements(By.xpath("//div[@class='react-datepicker__week']/div[@aria-disabled='false']"));
		return elements;
	}

	public WebElement email(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='email_id']"));
		return element;	
	}

	public WebElement get_password(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='new-password']"));
		return element;	
	}

	public WebElement confirm_password(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='c-password']"));
		return element;	
	}

	public WebElement accept_terms(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@for='defaultCheck1']"));
		return element;	

	}

	public WebElement submit(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//div[contains(@class,'mt-40 px-sm-4 col-auto')]//a/button"));
		return element;	
	}

	public WebElement verify(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//button[@class='btn btn-red plr-50']"));
		return element;	
	}





}
