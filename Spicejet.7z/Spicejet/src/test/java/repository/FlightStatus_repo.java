package repository;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class FlightStatus_repo 
{
	
	WebElement element;
	 List<WebElement> elements;
	
	public WebElement button(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//div[@class='css-1dbjc4n r-1d09ksm r-qklmqi r-1lz4bg0 r-1phboty r-18u37iz']//div[3]//div[2]"));
		return element;
	}
	
	
	public WebElement dd_dropdown(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//div[@class='css-1dbjc4n r-14lw9ot r-11u4nky r-z2wwpe r-1phboty r-rs99b7 r-1loqt21 r-8oi148 r-1777fci r-ymttw5 r-5njf8e r-1otgn73']"));
		return element;
	}
	
	public List<WebElement> dd_text(WebDriver driver)
	{
		elements=driver.findElements(By.xpath("//div[@class='css-76zvg2 r-qsz3a2 r-18tvxmy r-1i10wst r-1kfrs79']"));
		return elements;
	}
	public WebElement from(WebDriver driver)
	{
		element=driver.findElement(By.xpath("(//div[@class='css-1dbjc4n r-14lw9ot r-11u4nky r-z2wwpe r-1phboty r-rs99b7 r-1loqt21 r-13awgt0 r-ymttw5 r-tju18j r-5njf8e r-1otgn73'])[1]"));
		return element;
	}
	public WebElement from_outer(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//div[@class='css-1dbjc4n r-knv0ih r-1k1q3bj r-ql8eny r-1dqxon3']"));
		return element;
	}
	public WebElement from_international(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//div[@class='css-76zvg2 r-cqee49 r-ubezar r-1ozqkpa'][normalize-space()='International']"));
		return element;
	}
	public List<WebElement> from_inner(WebDriver driver)
	{
		elements=driver.findElements(By.xpath("//div[@class='css-76zvg2 r-cqee49 r-ubezar r-1kfrs79']"));
		return elements;
	}
	public WebElement flightNo(WebDriver driver)
	{
		element=driver.findElement(By.xpath("(//input[@value='SG - '])"));
		return element;
	}
	public WebElement searchButton(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//div[@class='css-1dbjc4n r-1awozwy r-19m6qjp r-z2wwpe r-1loqt21 r-18u37iz r-1777fci r-1w50u8q r-ah5dr5 r-1otgn73 r-13qz1uu']"));
		return element;
	}
	
	public WebElement searchResult(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//div[@class='css-1dbjc4n r-1awozwy r-19m6qjp r-z2wwpe r-1loqt21 r-18u37iz r-1777fci r-1w50u8q r-ah5dr5 r-1otgn73 r-13qz1uu']"));
		return element;
	}
	
	public List<WebElement> resultList(WebDriver driver)
	{
		elements=driver.findElements(By.xpath("//div[@class='css-1dbjc4n r-14lw9ot r-z2wwpe r-9tkp46 r-ku1wi2']"));
		return elements
				;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
