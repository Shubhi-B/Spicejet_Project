package flightStatus;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import hooks.Instances;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import repository.FlightStatus_repo;


public class FlightStatus_StepDef extends Instances
{
	FlightStatus_repo status=new FlightStatus_repo();


	@Given("^User clicks on flight status$")
	public void user_clicks_on_flight_status()
	{
		status.button(driver).click();
	}

	@When("^\"(.*)\" is selected in departure date$")
	public void departure(String input) throws InterruptedException 
	{
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='css-1dbjc4n r-14lw9ot r-11u4nky r-z2wwpe r-1phboty r-rs99b7 r-1loqt21 r-8oi148 r-1777fci r-ymttw5 r-5njf8e r-1otgn73']")));
		status.dd_dropdown(driver).click();

		for(WebElement element:status.dd_text(driver))
		{
			if(element.getText().equalsIgnoreCase(input))
			{
				element.click();
				break;
			}
		}

	}
	String f;
	@When("^\"(.*)\" is selected from from dropdown$")
	public void is_selected_from_from_dropdown(String from) throws InterruptedException 
	{
		Thread.sleep(3000);
		f=from;
		status.from(driver).click();
		if(status.from_outer(driver).getText().contains(from))
		{
			System.out.println(status.from_outer(driver).getText());
			for(WebElement element:status.from_inner(driver))
			{
				if(element.getText().equalsIgnoreCase(from))
				{
					element.click();
					break;
				}
			}
		}

		else
		{
			status.from_international(driver).click();
			for(WebElement element:status.from_inner(driver))
			{
				if(element.getText().contains(from))
				{
					element.click();
					break;
				}
			}
		}

	}
	String t;
	@When("^\"(.*)\" is selected from to dropdown$")
	public void is_selected_from_to_dropdown(String to) throws InterruptedException {
		Thread.sleep(6000);
		t=to;
		if(status.from_outer(driver).getText().contains(to))
		{
			for(WebElement element:status.from_inner(driver))
			{
				if(element.getText().equalsIgnoreCase(to))
				{
					element.click();
					break;
				}
			}
		}

		else
		{
			status.from_international(driver).click();
			for(WebElement element:status.from_inner(driver))
			{
				if(element.getText().equalsIgnoreCase(to))
				{
					element.click();
					break;
				}
			}
		}
	}

	@When("^\"(.*)\" is entered in flight number field$")
	public void is_entered_in_flight_number_field(String fNum)
	{
		if(!fNum.isBlank())
		{
			status.flightNo(driver).sendKeys(fNum);
		}
	}

	@When("^Search flights button is clicked$")
	public void search_flights_button_is_clicked() 
	{
		status.searchButton(driver).click();
	}

	@Then("^user sees flight status results$")
	public void user_sees_search_results() throws InterruptedException 
	{

		try
		{
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='css-1dbjc4n r-14lw9ot r-z2wwpe r-9tkp46 r-ku1wi2']")));
			
			for(WebElement element:status.resultList(driver))
			{
				String t= element.getText();
				System.out.println(t);
				wait.until(ExpectedConditions.elementToBeClickable(element));
				a.moveToElement(element).click().perform();
			}

		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			System.out.println("--------Error in Search Or No results Found---------");
		}
	}
}



